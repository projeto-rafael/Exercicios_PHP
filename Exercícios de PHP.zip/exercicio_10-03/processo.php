<!DOCTYPE html>
<html lang="pt0br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste com PHP</title>
</head>
<body>
    


    <?php
        $num1 = $_REQUEST{'num1'};
        $num2 = $_REQUEST{'num2'};
        $num3 = $_REQUEST{'num3'};
        $media = ($num1 + $num2 + $num3)/3;
        
        echo "A média destes 3 números é: " .$media;
        
        /* Método 2: 
        $soma = $num1 + $num2 + $num3;
        $media = 3;
        
        $resultado = $soma / $media;

        echo "A média destes 3 números é: .$resultado"
        */
       
    ?>
</body>
</html>