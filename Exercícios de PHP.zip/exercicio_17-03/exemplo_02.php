<?php

    # Utilização do Elseif: 

    $nota = 5.5;

    
    if ($nota>6){
        echo "Você está Aprovado";
    }

    elseif ($nota<5) {
        echo "Você está reprovado";
    }

    else{
        echo "Recuperação";
    }
    