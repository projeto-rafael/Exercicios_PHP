<?php

    # Condicionais 

    $nota = 5.5;
 
    if ($nota>5){
        // Caso a nota seja maior que 5.5 faça isso: 
        echo "APROVADO";
    }
    else{
        // Caso a nota seja menor que 5.5 faça isso: 
        echo "REPROVADO";
    }
?>