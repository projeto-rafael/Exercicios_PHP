<?php


    # Exercício sobre PHP - Condicionais

/*  a)  idade = 17,
    b)  idade = 20, 
    c)  idade = 18, 
    b)  idade = 15,  */

    $idade = 15;
    $habilitacao = TRUE;

    $teste = "";
    if ($habilitacao == TRUE){
        $teste = "SIM";
    }else {
        $teste = "NÃO";
    }

    echo "Sua idade é: $idade <br>";
    echo "Tem habilitação: $teste <br>";
    echo "<br>"; *

    if ($idade>=18){

        if ($habilitacao == TRUE){

            echo "<b>Você pode dirigir</b>";
        }else {

            echo "<b>Você não pode dirigir - NÃO TEM HABILITAÇÃO</b>";
        }
    }
    
    else {
        if ($habilitacao == TRUE){

            echo "<b>Você não pode dirigir - NÃO TEM IDADE APESAR DE TER HABILITAÇÃO</b>";
        }else {

            echo "<b>Você não pode dirigir - NÃO TEM IDADE E NEM HABILITAÇÃO</b>";
        }
        
    }
?>