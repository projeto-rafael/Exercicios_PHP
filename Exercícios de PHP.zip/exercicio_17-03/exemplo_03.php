<?php

    # Utilização do SWITCH 

$sigla = "SP";

switch ($sigla){  

    case "SP":
        echo "Você escolheu São Paulo";
        break;

    case "RJ":
        echo "Você escolheu Rio de Janeiro";
        break;

    case "MG":
        echo "Você escolheu Minas Gerais";
        break;

    default:
        echo "NÃO ENCONTREI ESTA SIGLA!";
        break;
}
