<?php
    echo "<h3>Pós-incremento</h3>";
    $a = 5;
    echo "Deve ser 5: " . $a-- . "<br />\n";
    echo "Deve ser 6:  $a <br />\n";
?>
