<?php
   
    # Comparação em PHP

    $a = "10";
    $b = 10;
    $soma = $a + $b;

    echo "Usando == :". ($a == $b); 
    # Utilizando dois sinais de = é comparado apenas o valor, sem depender do tipo da variável;
    echo "<br>";

    echo "Usando === :". ($a === $b);
    #Utilizando três sinais de = é comparado o valor e o tipo da variável;
    echo "<br>";

    echo "Somando a + b => ". $soma;
    echo "<br>";


    # A função var_dump demonstra o qual o tipo e o que possui na variável, como o typeof em JS; 
    var_dump($a); 
    echo "<br>";
    var_dump($b);
?>