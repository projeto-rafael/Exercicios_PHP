<?php

    # Operações com PHP;

    $soma = ($valor1 = 4) + 5; // Variável soma é de 9;
    $valor2 = 20; 
    $valor3 = 30;
    $soma += 1; // O += é um tipo de Atribuição. Fazendo com que a variável soma seja 10;

    $soma += $valor2; // Atribuição com Soma;
    $soma *= $valor3; // Atribuição com Multiplicação;
    $soma %= 100; // Atribuição com módulos;

    $saudacao = "Bom ";
    $saudacao .= "Dia!"; 
    $saudacao = $saudacao . "Dia!";
    echo $saudacao . "Hoje vai ter " . $soma . " % tristeza!";


?>